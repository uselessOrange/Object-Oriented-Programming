#include <iostream>
#include <string>
using namespace std;
 int main() {
	string text;
	cout << "Enter a string " << endl;
	cin >> text;
	cout << "\nThis is your string:\t " << text
		<< endl;
	return 0;
}

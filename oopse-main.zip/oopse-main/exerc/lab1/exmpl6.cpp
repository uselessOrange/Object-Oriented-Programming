#include <iostream>
using namespace std;
int main() {
	int i=1;
	do {
		cout << "Wartosc i to: " << i << endl;
		i++;
	} while(i<=4 && i>=2);
	return 0;
}


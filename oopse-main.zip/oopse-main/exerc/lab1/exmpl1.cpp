#include <iostream>
int main() {
	std::cout << "Hello world! \n";
	std::cout <<"Again" << "Hello"
		<< "world!" << "\n";
	return 0;
}


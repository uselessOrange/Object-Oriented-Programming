#ifndef MAGE_H
#define MAGE_H

#include "CharacterClassBase.h"

namespace RPG {
	class Mage : public CharacterClassBase
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !MAGE_H
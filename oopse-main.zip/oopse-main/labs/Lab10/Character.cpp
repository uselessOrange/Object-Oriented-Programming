#include "Character.h"

RPG::Character::Character(void) {}

RPG::Character::Character(std::string name, int str, int dex, int end, int intel, int chari) {
	this->name = name;
	this->strength = str;
	this->dexterity = dex;
	this->endurance = end;
	this->intelligence = intel;
	this->charisma = chari;
}


void RPG::Character::printData(void) {
	std::cout << "Your character is: " << std::endl
		<< "Name: " << this->name << std::endl
		<< "Stats:" << std::endl
		<< "Strength: " << this->strength << std::endl
		<< "Dexterity: " << this->dexterity << std::endl
		<< "Endurance: " << this->endurance << std::endl
		<< "Intelligence: " << this->intelligence << std::endl
		<< "Charisma: " << this->charisma << std::endl;
}

std::string RPG::Character::getName(void) {
	return this->name;
}

int RPG::Character::getStrength(void) {
	return this->strength;
}

int RPG::Character::getDexterity(void) {
	return this->dexterity;
}

int RPG::Character::getEndurance(void) {
	return this->endurance;
}

int RPG::Character::getIntelligence(void) {
	return this->intelligence;
}

int RPG::Character::getCharisma(void) {
	return this->charisma;
}

RPG::Character::~Character(void) {}
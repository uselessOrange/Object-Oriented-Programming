#ifndef WARRIOR_H
#define WARRIOR_H

#include "CharacterClassBase.h"

namespace RPG {
	class Warrior : public CharacterClassBase
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !WARRIOR_H
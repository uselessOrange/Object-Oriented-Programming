#include <iostream>
#include<string>
#include <fstream>
#include "Character.h"
#include "CharacterClasses.h"
#include <vector>

#ifdef __linux__
#include <stdlib.h>
#define hold() system("read")
#define wipeScreen() system("clear")
#endif // __linux__

#ifdef _WIN32
#define wipeScreen() system("CLS")
#define hold() system("pause")
#endif // _WIN32

void wipeCin(void);
RPG::Character* createCharacter(void);
RPG::Character* loadCharacter(void);
RPG::Monster monster;

int main() {
	srand((unsigned int)time(NULL));
	RPG::Character* userCharacter = NULL;
	std::vector<RPG::Monster*> potworki;
	char YNanswer;
	std::fstream characterFile, monstersFile;

	for (;;) {
		int option = 0;
		while (option != 1 && option != 2) {
			wipeScreen();
			std::cout << "Choose:" << std::endl
				<< "(1) Create new character" << std::endl
				<< "(2) Load existing character" << std::endl;
			std::cin >> option;
			wipeCin();
		}
		wipeScreen();

		switch (option) {
		case 1:
			userCharacter = createCharacter();
			break;
		case 2:
			userCharacter = loadCharacter();
			break;
		}

		wipeScreen();

		if (userCharacter != NULL) {
			userCharacter->printData();
			std::cout << "Do you want to save this character? (Y/N): ";
			std::cin >> YNanswer;
			wipeCin();

			if (YNanswer == 'Y' || YNanswer == 'y') {
				characterFile.open(userCharacter->getName(), std::ios::out);
				characterFile << userCharacter->getStrength() << ' '
					<< userCharacter->getDexterity() << ' '
					<< userCharacter->getEndurance() << ' '
					<< userCharacter->getIntelligence() << ' '
					<< userCharacter->getCharisma();
				characterFile.close();
			}
		}
		wipeScreen();

		std::cout << "Do you want to generate monsters? (Y/N): ";
		std::cin >> YNanswer;
		wipeCin();

		if (YNanswer == 'Y' || YNanswer == 'y') {

			for (int i = 0; i < 5; i++) {
				potworki.push_back(new RPG::Monster);
				std::cout << "Monster " << i << " -"
					<< " S: " << potworki.at(i)->getStrength()
					<< " D: " << potworki.at(i)->getDexterity()
					<< " E: " << potworki.at(i)->getEndurance()
					<< " I: " << potworki.at(i)->getIntelligence()
					<< " C: " << potworki.at(i)->getCharisma() << std::endl;
			}
			std::cout << "Do you want to save them? (Y/N): ";
			std::cin >> YNanswer;
			wipeCin();
			if (YNanswer == 'Y' || YNanswer == 'y') {
				monstersFile.open("monsters", std::ios::out);
				for (int i = 0; i < 5; i++) {
					monstersFile << "Monster " << i << " -"
						<< " S: " << potworki.at(i)->getStrength()
						<< " D: " << potworki.at(i)->getDexterity()
						<< " E: " << potworki.at(i)->getEndurance()
						<< " I: " << potworki.at(i)->getIntelligence()
						<< " C: " << potworki.at(i)->getCharisma() << std::endl;
				}
				monstersFile.close();
			}
		}

	}
	return 0;
}

void wipeCin(void) {
	std::cin.clear();
	std::cin.ignore(10000, '\n');
	return;
}

RPG::Character* createCharacter(void) {
	RPG::Warrior warek;
	RPG::Berserker berek;
	RPG::Mage mag;
	RPG::Thief kradziej;
	int classChoice;
	std::string tName;
	int tStr, tDex, tEnd, tInt, tChar;
	std::cout << "Enter your name: ";
	std::cin >> tName;
	wipeCin();
	std::cout << "Enter your stats below:" << std::endl;
	std::cout << "Strength: ";
	std::cin >> tStr;
	wipeCin();
	std::cout << "Dexterity: ";
	std::cin >> tDex;
	wipeCin();
	std::cout << "Endurance: ";
	std::cin >> tEnd;
	wipeCin();
	std::cout << "Intelligence: ";
	std::cin >> tInt;
	wipeCin();
	std::cout << "Charisma: ";
	std::cin >> tChar;
	wipeCin();
	std::cout << "Choose your class: " << std::endl
		<< "(1) Warrior" << std::endl
		<< "(2) Berserker" << std::endl
		<< "(3) Mage" << std::endl
		<< "(4) Thief" << std::endl;
	std::cin >> classChoice;
	wipeCin();
	RPG::Character* tCharacter = new RPG::Character(tName, tStr, tDex, tEnd, tInt, tChar);
	switch (classChoice) {
	case 1:
		warek.applyBuff(tCharacter);
		break;
	case 2:
		berek.applyBuff(tCharacter);
		break;
	case 3:
		mag.applyBuff(tCharacter);
		break;
	case 4:
		kradziej.applyBuff(tCharacter);
		break;
	}

	return tCharacter;
}

RPG::Character* loadCharacter(void) {
	std::string tName;
	int tStr, tDex, tEnd, tInt, tChar;
	std::fstream tFile;

	std::cout << "Enter the saved character's name: ";
	std::cin >> tName;
	wipeCin();
	tFile.open(tName, std::ios::in);
	if (!tFile.is_open()) {
		std::cout << "No file found." << std::endl;
		hold();
		return NULL;
	}
	tFile >> tStr >> tDex >> tEnd >> tInt >> tChar;
	tFile.close();

	return new RPG::Character(tName, tStr, tDex, tEnd, tInt, tChar);
}

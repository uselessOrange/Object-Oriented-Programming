#ifndef BERSERKER_H
#define BERSERKER_H

#include "CharacterClassBase.h"

namespace RPG {
	class Berserker : public CharacterClassBase
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !BERSERKER_H
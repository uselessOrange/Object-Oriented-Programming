#ifndef CHARACTER_H
#define CHARACTER_H

#include <iostream>
#include <string>

#include "LivingCreatureBase.h"

namespace RPG {
	class Character : public LivingCreatureBase {

	public:
		Character(void);
		Character(std::string, int, int, int, int, int);

		void printData(void);
		std::string getName(void);
		int getStrength(void);
		int getDexterity(void);
		int getEndurance(void);
		int getIntelligence(void);
		int getCharisma(void);


		~Character(void);

	

		friend class Warrior;
		friend class Mage;
		friend class Thief;
		friend class Berserker;
	};
}

#endif // !CHARACTER_H

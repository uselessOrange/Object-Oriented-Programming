#include "Mage.h"
void RPG::Mage::applyBuff(Character* character) {
	character->intelligence += 5;
}
#ifndef MONSTER_H
#define MONSTER_H

#include <random>
#include <time.h>
#include "LivingCreatureBase.h"

namespace RPG {
	class Monster : public LivingCreatureBase {
	public:
		Monster(void);

		int getStrength(void);
		int getDexterity(void);
		int getEndurance(void);
		int getIntelligence(void);
		int getCharisma(void);
	};
}

#endif // !MONSTER_H
#include "Berserker.h"
void RPG::Berserker::applyBuff(Character* character) {
	character->strength += 5;
}
#ifndef LIVINGCREATUREBASE_H
#define LIVINGCREATUREBASE_H

#include <string>

namespace RPG {

	class LivingCreatureBase {
	public:
		std::string name;
		int strength;
		int dexterity;
		int endurance;
		int intelligence;
		int charisma;

		virtual int getStrength(void)=0;
		virtual int getDexterity(void)=0;
		virtual int getEndurance(void)=0;
		virtual int getIntelligence(void)=0;
		virtual int getCharisma(void)=0;
	};
}

#endif // !LIVINGCREATUREBASE_H



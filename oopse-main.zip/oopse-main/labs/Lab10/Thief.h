#ifndef THIEF_H
#define THIEF_H

#include "CharacterClassBase.h"

namespace RPG {
	class Thief : public CharacterClassBase
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !THIEF_H
#include "Warrior.h"
void RPG::Warrior::applyBuff(Character* character) {
	character->endurance += 5;
}
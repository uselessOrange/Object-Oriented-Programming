#ifndef CHARACTERCLASSBASE_H
#define CHARACTERCLASSBASE_H

#include "Character.h"

namespace RPG {

class CharacterClassBase {
public:
	virtual void applyBuff(Character*) = 0;
};
}

#endif // !CHARACTERCLASSBASE_H
#include "Thief.h"
void RPG::Thief::applyBuff(Character* character) {
	character->dexterity += 5;
}
#include "Monster.h"

RPG::Monster::Monster(void) {
	this->strength = rand() % 10 + 1;
	this->dexterity = rand() % 10 + 1;
	this->endurance = rand() % 10 + 1;
	this->intelligence = rand() % 10 + 1;
	this->charisma = rand() % 10 + 1;
}

int RPG::Monster::getStrength(void) {
	return this->strength;
}

int RPG::Monster::getDexterity(void) {
	return this->dexterity;
}

int RPG::Monster::getEndurance(void) {
	return this->endurance;
}

int RPG::Monster::getIntelligence(void) {
	return this->intelligence;
}

int RPG::Monster::getCharisma(void) {
	return this->charisma;
}
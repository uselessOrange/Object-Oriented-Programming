#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <tgmath.h>
#define ever (;;)

int validateSelection(int*, int);
void dispenseItem(std::string*, int*, float*);
int giveChange(int*, int*, float);


int moneyCount[6];
	const float denomination[6] = { 5, 2, 1, 0.50, 0.20, 0.10 };

int main(void) {
	std::string productName[5];
	int quantity[5];
	float price[5];
	int needsRefill[5];
	

	for (int i = 0; i < 6; i++) {
		std::cout << "Input amount of " << denomination[i] << " PLN coins: ";
		std::cin >> moneyCount[i];
	}

	std::ofstream kasaOut("moneyList.txt");

	for (int i = 0; i < 6; i++) {
		kasaOut << moneyCount[i]<<std::endl;
	}

	kasaOut.close();

	std::ifstream plikIn("itemList.txt");

	for (int i = 0; i < 5; i++) {
		plikIn >> productName[i] >> quantity[i] >> price[i]>> needsRefill[i];
		if (needsRefill[i] == 1) {
			quantity[i] = 10;
			needsRefill[i] = 0;
		}
	}

	plikIn.close();

	for ever{
		int itemNumber;
		std::cout << std::setw(7) << std::left << "Number" << std::setw(10) << std::left << "Product" << std::setw(10) << "Price" << std::setw(10) << "Quantity" << std::endl;
		for (int i = 0; i < 5; i++) {
			std::cout << std::setw(7) << std::left << i + 1 << std::setw(10) << std::left << productName[i] << std::setw(10) << price[i] << std::setw(10) << quantity[i] << std::endl;
	}
			std::cout << std::endl;
			std::cout << "Choose a product: ";

			std::cin >> itemNumber;
			itemNumber = validateSelection(&itemNumber,5) - 1;

			while (quantity[itemNumber] < 1) {
				std::cout << "Out of stock. Choose a product: " << std::endl;
			std::cin >> itemNumber;
			itemNumber = validateSelection(&itemNumber,5) - 1;
			}
			dispenseItem(&productName[itemNumber], &quantity[itemNumber], &price[itemNumber]);

			std::ofstream plikOut("itemList.txt");
			for (int i = 0; i < 5; i++) {
				if (quantity[i] < 1) needsRefill[i] = 1;
				plikOut << productName[i] << " " << quantity[i] << " " << price[i] << " " << needsRefill[i] << std::endl;
			}
			plikOut.close();

	std::ifstream plikIn("itemList.txt");

	for (int i = 0; i < 5; i++) {
		plikIn >> productName[i] >> quantity[i] >> price[i] >> needsRefill[i];
	}

	plikIn.close();

	}
	return 0;

}

int validateSelection(int* selection, int limit) {
	for ever{
	if (*selection == 1111) exit(EXIT_SUCCESS);

	if (*selection == 666) {
		for (int i = 0; i < 6; i++) {
			std::cout << "Input amount of " << denomination[i] << " PLN coins: ";
			std::cin >> moneyCount[i];
		}

		std::ofstream kasaOut("moneyList.txt");

		for (int i = 0; i < 6; i++) {
			kasaOut << moneyCount[i] << std::endl;
		}

		kasaOut.close();
	std::cout << "Select item: " << std::endl;
	std::cin >> *selection;
	}


	if (0 <= *selection && *selection <= limit)return *selection;
	std::cout << "Invalid input. Try again." << std::endl;
	std::cin >> *selection;
	}
}

void dispenseItem(std::string* name, int* amount, float* price) {
	int selectedAmount;
	int insertedMoney[6];
	std::cout << "How many " << *name << "s do you want: " << std::endl;
	std::cin >> selectedAmount;
	float totalPrice = selectedAmount * *price;
	validateSelection(&selectedAmount, *amount);

	int restability = 1;
	while (restability != 0) {

	std::cout << "Price: " << totalPrice << std::endl;
	std::cout << "Insert money (amount of 5, 2, 1, 0.5, 0.2, 0.1 PLN coins separated by spaces)"<<std::endl;
	std::cin >> insertedMoney[0]
		>> insertedMoney[1]
		>> insertedMoney[2]
		>> insertedMoney[3]
		>> insertedMoney[4]
		>> insertedMoney[5];

	float insertedSum = 0;
	for (int i = 0; i < 6; i++) {
		insertedSum += insertedMoney[i] * denomination[i];
	}

	while (insertedSum < totalPrice) {
		std::cout << "Incorrect amount inserted, try again:" << std::endl;
		std::cout << "Insert money (amount of 5, 2, 1, 0.5, 0.2, 0.1 PLN coins separated by spaces)" << std::endl;
		std::cin >> insertedMoney[0]
			>> insertedMoney[1]
			>> insertedMoney[2]
			>> insertedMoney[3]
			>> insertedMoney[4]
			>> insertedMoney[5];

		insertedSum = 0;
		for (int i = 0; i < 6; i++) {
			insertedSum += insertedMoney[i]*denomination[i];
		}
}

	restability = giveChange(moneyCount, insertedMoney, insertedSum - totalPrice);
	}
	
	

	*amount -= selectedAmount;

	std::cout << "Thank you for your purchase" << std::endl;
	std::cout << std::endl;
}

int giveChange(int* moneyPool, int* insertedMoney, float changeToGive) {
	if (changeToGive == 0) return 0;
	float changeSum = 0;
	while (changeSum < changeToGive) {
		int max = -1;
		int maxIndex = 0;
		for (int i = 0; i < 6; i++) {
			if (*(moneyPool + i) > max  && denomination[i] <= round((changeToGive-changeSum)*100)/100 && round(*(moneyPool + i) * denomination[i]*100)/100 >= round((changeToGive - changeSum)*100)/100) {
				max = *(moneyPool + i);
				maxIndex = i;
			}
		}
			if (max == -1) {
				std::cout << "Unable to give change, try different coins" << std::endl;
				return -1;
			}
		changeSum += denomination[maxIndex];

		(*(moneyPool + maxIndex))--;
	}
	
	for (int i = 0; i < 6; i++) {
		*(moneyPool + i) += *(insertedMoney + i);

	}

	std::ofstream kasaOut("moneyList.txt");

	for (int i = 0; i < 6; i++) {
		kasaOut << moneyCount[i] << std::endl;
	}

	kasaOut.close();

	std::cout << changeSum << "PLN dropped as change"<< std::endl;
		return 0;
}

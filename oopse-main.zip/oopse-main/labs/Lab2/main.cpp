#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>

#define ever (;;)

int validateSelection(int*, int);
void dispenseItem(std::string*, int*);

int main(void) {
	std::string productName[5];
	int quantity[5];
	int needsRefill[5];

	std::ifstream plikIn("itemList.txt");

	for (int i = 0; i < 5; i++) {
		plikIn >> productName[i] >> quantity[i] >> needsRefill[i];
		if (needsRefill[i] == 1) {
			quantity[i] = 10;
			needsRefill[i] = 0;
		}
	}

	plikIn.close();

	for ever{
		int itemNumber;
		std::cout << std::setw(7) << std::left << "Number" << std::setw(10) << std::left << "Product" << "Quantity" << std::endl;
		for (int i = 0; i < 5; i++) {
			std::cout << std::setw(7) << std::left << i + 1 << std::setw(10) << std::left << productName[i] << quantity[i] << std::endl;
	}
			std::cout << std::endl;
			std::cout << "Choose a product: ";
			
			std::cin >> itemNumber;
			itemNumber = validateSelection(&itemNumber,5) - 1;

			while (quantity[itemNumber] < 1) {
				std::cout << "Out of stock. Choose a product: " << std::endl;
			std::cin >> itemNumber;
			itemNumber = validateSelection(&itemNumber,5) - 1;
			}
			dispenseItem(&productName[itemNumber], &quantity[itemNumber]);

			std::ofstream plikOut("itemList.txt");
			for (int i = 0; i < 5; i++) {
				if (quantity[i] < 1) needsRefill[i] = 1;
				plikOut << productName[i] << " " << quantity[i] << " " << needsRefill[i] << std::endl;
			}
			plikOut.close();

	std::ifstream plikIn("itemList.txt");

	for (int i = 0; i < 5; i++) {
		plikIn >> productName[i] >> quantity[i] >> needsRefill[i];
	}

	plikIn.close();

	}
	return 0;

}

int validateSelection(int* selection, int limit) {
	if (*selection == 1111) exit(EXIT_SUCCESS);
	for ever{
	if (0 < *selection && *selection <= limit)return *selection;
	std::cout << "Invalid input. Try again." << std::endl;
	std::cin >> *selection;
	}
}

void dispenseItem(std::string* name, int* amount) {
	int selectedAmount;
	std::cout << "How many " << *name << "s do you want: " << std::endl;
	std::cin >> selectedAmount;
	validateSelection(&selectedAmount, *amount);
	*amount -= selectedAmount;
	std::cout << "Thank you for your purchase" << std::endl;
	std::cout << std::endl;
}
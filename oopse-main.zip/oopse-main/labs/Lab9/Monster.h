#ifndef MONSTER_H
#define MONSTER_H

#include <random>
#include <time.h>
#include "Character.h"

namespace RPG {
	class Monster : public Character
	{
	public:
		Monster(void);
	};
}

#endif // !MONSTER_H
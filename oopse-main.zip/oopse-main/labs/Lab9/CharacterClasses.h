#ifndef CHARACTERCLASSES_H
#define CHARACTERCLASSES_H

#include "Warrior.h"
#include "Thief.h"
#include "Mage.h"
#include "Berserker.h"
#include "Monster.h"

#endif // !CHARACTERCLASSES_H
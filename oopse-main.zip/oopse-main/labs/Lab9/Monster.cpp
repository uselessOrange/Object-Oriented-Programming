#include "Monster.h"

RPG::Monster::Monster(void) {
	this->strength = rand() % 10 + 1;
	this->dexterity = rand() % 10 + 1;
	this->endurance = rand() % 10 + 1;
	this->intelligence = rand() % 10 + 1;
	this->charisma = rand() % 10 + 1;
}
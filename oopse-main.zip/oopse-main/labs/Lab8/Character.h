#ifndef CHARACTER_H
#define CHARACTER_H

#include <iostream>
#include <string>

namespace RPG {
	class Character {
	public:
		Character(void);
		Character(std::string, int, int, int, int, int);

		void printData(void);
		std::string getName(void);
		int getStrength(void);
		int getDexterity(void);
		int getEndurance(void);
		int getIntelligence(void);
		int getCharisma(void);

		~Character(void);

	private:
		std::string name;
		int strength;
		int dexterity;
		int endurance;
		int intelligence;
		int charisma;

		friend class Warrior;
		friend class Mage;
		friend class Thief;
		friend class Berserker;
	};
}

#endif // !CHARACTER_H

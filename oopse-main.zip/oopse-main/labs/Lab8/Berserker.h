#ifndef BERSERKER_H
#define BERSERKER_H

#include "Character.h"

namespace RPG {
	class Berserker
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !BERSERKER_H
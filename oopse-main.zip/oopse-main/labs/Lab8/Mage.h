#ifndef MAGE_H
#define MAGE_H

#include "Character.h"

namespace RPG {
	class Mage
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !MAGE_H
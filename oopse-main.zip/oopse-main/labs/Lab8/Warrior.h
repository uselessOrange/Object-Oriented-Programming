#ifndef WARRIOR_H
#define WARRIOR_H

#include "Character.h"

namespace RPG {
	class Warrior
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !WARRIOR_H
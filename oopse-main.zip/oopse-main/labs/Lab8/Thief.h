#ifndef THIEF_H
#define THIEF_H

#include "Character.h"

namespace RPG {
	class Thief
	{
	public:
		void applyBuff(Character* character);
	};
}
#endif // !THIEF_H
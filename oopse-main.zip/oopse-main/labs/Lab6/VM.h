#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <map>

namespace VM {
	enum _state {
		Init,
		ReadyToSell,
		CreateOrder,
		Transaction,
		GiveChange,
		ServiceMode,
	};



	class Item {

	public:

		Item(std::string, int, int, std::string);

		std::string getName();
		std::string setName(std::string);
		int getPrice();
		int setPrice(int);
		int getAmount();
		int setAmount(int);
		std::string getInStockFlag();
		std::string setInStockFlag();
		std::string resetInStockFlag();


		int changeItem(std::string, int, int);
		int changePrice(int);
		int restock(int);
		int sell(int);

	private:

		std::string name = "";
		int price = 0;
		int amount = 0;
		std::string inStockFlag = "";
	};

	class Machine {

	public:
		_state state = Init;
		Machine();
		Machine(std::string, std::string);

		int getTransactionBalance();
		int setTransactionBalance(int);
		std::vector<Item*> getItem();

		void initialize();
		void presentMenu();
		void validateItem(int*);
		void validateAmount(int*, int*);
		int calculatePrice(int*);
		bool attemptSale(int*, int*);
		int calculateChange();
		void endSale();
		bool updateCashFile();
		void editCashPool(std::map<int, int>*);
		std::map<int, int>* getCashPool();
		void dealWithChange(int*, int*);

	private:
		std::vector<Item*> item;
		int transactionBalance = 0;
		int insertedBalance = 0;
		std::string itemFileName = "";
		std::string cashFileName = "";
		std::fstream itemFile;
		std::fstream cashFile;
		int serviceCode = 1234;
		int killSwitch = 1111;
		std::map<int, int> cashPool = {
			{500,0},
			{200,0},
			{100,0},
			{50,0},
			{20,0},
			{10,0}
		};
		std::map<int, int> insertedCash = {
			{500,0},
			{200,0},
			{100,0},
			{50,0},
			{20,0},
			{10,0}
		};

		bool wait(int);
		bool loadItems();
		bool writeItems();
	};
}
#include "VM.h"

VM::Item::Item(std::string name, int price, int amount, std::string inStockFlag) {
	this->name = name;
	this->price = price;
	this->amount = amount;
	this->inStockFlag = inStockFlag;
}

std::string VM::Item::getName() {
	return this->name;
}

std::string VM::Item::setName(std::string newName) {
	return this->name = newName;
}

int VM::Item::getPrice() {
	return this->price;
}

int VM::Item::setPrice(int newPrice) {
	return this->price = newPrice;
}

int VM::Item::getAmount() {
	return this->amount;
}

int VM::Item::setAmount(int newAmount) {
	return this->amount = newAmount;
}

std::string VM::Item::getInStockFlag() {
	return this->inStockFlag;
}

std::string VM::Item::setInStockFlag() {
	return this->inStockFlag = "ok";
}

std::string VM::Item::resetInStockFlag() {
	return this->inStockFlag = "nok";
}

int VM::Item::changeItem(std::string newName, int newPrice, int newAmount) {
	this->name = newName;
	this->price = newPrice;
	return this->amount = newAmount;
}

int VM::Item::changePrice(int newPrice) {
	return this->price = newPrice;
}

int VM::Item::restock(int addedAmount) {
	return this->amount += addedAmount;
}

int VM::Item::sell(int amountSold) {
	return this->amount -= amountSold;

}

VM::Machine::Machine() {}

VM::Machine::Machine(std::string fileName, std::string cashFileName) {
	this->itemFileName = fileName;
	this->cashFileName = cashFileName;
}

int VM::Machine::getTransactionBalance() {
	return this->transactionBalance;
}

int VM::Machine::setTransactionBalance(int newTransactionBalance) {
	return this->transactionBalance = newTransactionBalance;
}

std::vector<VM::Item*> VM::Machine::getItem() {
	return this->item;
}

void VM::Machine::initialize() {
	loadItems();
	for (int i = 0; i < this->item.size(); i++) {

		if (this->item[i]->getInStockFlag() == "nok") {
			this->item[i]->restock(10);
			this->item[i]->setInStockFlag();
		}
	}
	writeItems();
	editCashPool(&this->cashPool);
	updateCashFile();
	this->state = ReadyToSell;
}

void VM::Machine::presentMenu() {
	loadItems();
	for (int i = 0; i < this->item.size(); i++) {
		std::cout << i + 1 << ". "
			<< this->item[i]->getName()
			<< " price: " << (float)this->item[i]->getPrice() / 100
			<< " in stock: " << this->item[i]->getAmount()
			<< std::endl;
	}
}

void VM::Machine::validateItem(int* selectedItem) {
	system("CLS");

	if (*selectedItem == this->killSwitch)exit(EXIT_SUCCESS);

	if (*selectedItem == this->serviceCode) {
		this->state = ServiceMode;
		return;
	}

	if (*selectedItem <= this->item.size() && *selectedItem > 0 && this->item[*selectedItem - 1]->getAmount() != 0) {
		this->state = CreateOrder;
		return;
	}

	std::cout << "Invalid item!" << std::endl;
}

void  VM::Machine::validateAmount(int* selectedItem, int* selectedAmount) {
	if (*selectedAmount > this->item[*selectedItem - 1]->getAmount() || *selectedAmount <= 0) {
		system("CLS");
		std::cout << "Invalid amount!" << std::endl;
		return;
	}

	this->transactionBalance = this->item[*selectedItem - 1]->getPrice() * *selectedAmount;
	this->state = Transaction;
}

int VM::Machine::calculatePrice(int* moneyInserted) {
	/*system("CLS");
	if (*moneyInserted < 0) {
		std::cout << "Invalid amount" << std::endl;
		return this->transactionBalance;
	}
	this->transactionBalance -= *moneyInserted;
	if (this->transactionBalance <= 0) {
		this->state = GiveChange;
		return 0;
}*/

	return this->transactionBalance;
}

bool VM::Machine::attemptSale(int* selectedItem, int* selectedAmount) {
	if (this->transactionBalance <= 0) {
		this->item[*selectedItem - 1]->sell(*selectedAmount);
		if (this->item[*selectedItem - 1]->getAmount() == 0)
			this->item[*selectedItem - 1]->resetInStockFlag();
		return true;
	}

	return false;
}

int VM::Machine::calculateChange() {
	return this->transactionBalance == 0 ? 0 : -this->transactionBalance;
}

void VM::Machine::endSale() {
	std::cout << "Thank you!" << std::endl;

	writeItems();

	this->wait(5);
	system("CLS");
	this->state = ReadyToSell;
}

bool VM::Machine::wait(int time) {
	time_t timer;
	time_t snapTime = std::time(&timer);

	while (std::time(&timer) < snapTime + time);
	return true;
}

bool VM::Machine::loadItems() {
	this->itemFile.open(this->itemFileName, std::ios::in);
	this->item.clear();
	std::string tName = "";
	int tPrice = 0;
	int tAmount = 0;
	std::string tInStockFlag = "";
	if (!(this->itemFile.is_open())) return false;
	while (!(this->itemFile.eof())) {
		itemFile >> tName >> tPrice >> tAmount >> tInStockFlag;
		this->item.push_back(new Item(tName, tPrice, tAmount, tInStockFlag));
	}
	this->itemFile.close();
	return true;
}

bool VM::Machine::writeItems() {
	this->itemFile.open(this->itemFileName, std::ios::out);
	if (!(this->itemFile.is_open())) return false;
	for (int i = 0; i < this->item.size() - 1; i++) {
		itemFile << this->item[i]->getName() << " "
			<< this->item[i]->getPrice() << " "
			<< this->item[i]->getAmount() << " "
			<< this->item[i]->getInStockFlag() << std::endl;
	}

	itemFile << this->item.back()->getName() << " "
		<< this->item.back()->getPrice() << " "
		<< this->item.back()->getAmount() << " "
		<< this->item.back()->getInStockFlag();

	this->itemFile.close();
	return true;
}

bool VM::Machine::updateCashFile() {
	this->cashFile.open(this->cashFileName, std::ios::out);
	if (!(this->cashFile.is_open()))return false;
	for (std::pair<float, int>denomination : this->cashPool) {
		cashFile << denomination.second << std::endl;
	}
	cashFile.close();
}

void VM::Machine::editCashPool(std::map<int, int>* pool) {
	for (std::pair<int, int> denomination : *pool) {
		std::cout << "Input amount of " << (float)denomination.first / 100 << " PLN coins: ";
		std::cin >> denomination.second;
		pool->at(denomination.first) = denomination.second;
		std::cin.clear();
		std::cin.ignore(10000, '\n');
	}
}

std::map<int, int>* VM::Machine::getCashPool() {
	return &this->cashPool;
}

void VM::Machine::dealWithChange(int* selectedItem, int* selectedAmount) {
	insertedBalance = 0;
	editCashPool(&this->insertedCash);
	for (std::pair<int, int> denomination : this->insertedCash) {
		this->insertedBalance += denomination.first * denomination.second;
	}

	if (this->insertedBalance < this->transactionBalance) {
		std::cout << "Insufficient funds, try again" << std::endl;
		return;
	}

	int changeSum = 0;
	int changeToGive = this->insertedBalance - this->transactionBalance;
	while (changeSum < changeToGive) {
		int maxAmount = -1;
		int maxDenomination = 0;

		for (std::pair<int, int> denomination : this->cashPool) {
			if (denomination.second > maxAmount
				&& denomination.first <= changeToGive - changeSum
				&& denomination.first * denomination.second >= changeToGive - changeSum) {
				maxAmount = denomination.second;
				maxDenomination = denomination.first;
			}
		}
		if (maxAmount == -1 && changeToGive != 0) {
			std::cout << "Unable to give change, try different coins" << std::endl;
			return;
		}
		changeSum += maxDenomination;
		this->cashPool[maxDenomination]--;
	}

	for (std::pair<int, int> denomination : this->insertedCash) {
		this->cashPool.at(denomination.first) += denomination.second;
	}
	updateCashFile();
	std::cout << (float)changeSum / 100 << " PLN dropped as change" << std::endl;
	this->item[*selectedItem - 1]->sell(*selectedAmount);
	if (this->item[*selectedItem - 1]->getAmount() == 0)
		this->item[*selectedItem - 1]->resetInStockFlag();
	writeItems();
	wait(3000);
	this->state = ReadyToSell;

}
#include "VM.h"
#define ever (;;)
//formatowanie konsoliu z biblioteki iomanip

int main() {
	VM::Machine* machine = new VM::Machine("itemList.txt", "cashList.txt");

	int selectedItem = 0;
	int selectedAmount = 0;
	int moneyInserted = 0;

	for ever{
		switch (machine->state) {
		case VM::Init:
			machine->initialize();
			break;

		case VM::ReadyToSell:
			system("CLS");
			selectedItem = 0;
			selectedAmount = 0;
			moneyInserted = 0;
			machine->setTransactionBalance(0);
			std::cout << "Welcome!" << std::endl;
			machine->presentMenu();
			std::cout << "Select item:" << std::endl;
			std::cin >> selectedItem;
			std::cin.clear();
			std::cin.ignore(10000, '\n');
			machine->validateItem(&selectedItem);
			break;

		case VM::CreateOrder:
			std::cout << "Selected: " << machine->getItem()[selectedItem - 1]->getName() << std::endl;
			std::cout << "Price: " << (float)machine->getItem()[selectedItem - 1]->getPrice()/100 << std::endl;
			std::cout << "Available amount: " << machine->getItem()[selectedItem - 1]->getAmount() << std::endl;
			std::cout << "Input amount:" << std::endl;
			std::cin >> selectedAmount;
			std::cin.clear();
			std::cin.ignore(10000, '\n');
			machine->validateAmount(&selectedItem, &selectedAmount);
			break;

		case VM::Transaction:
			
			std::cout << "To pay: " << (float)machine->calculatePrice(&moneyInserted)/100 << std::endl;
			if (!machine->attemptSale(&selectedItem, &selectedAmount)) {
				std::cout << "Insert money: " << std::endl;
				machine->dealWithChange(&selectedItem, &selectedAmount);
			}
			break;

		case VM::GiveChange:
			std::cout << "Your change: " << machine->calculateChange() << std::endl;
			machine->endSale();
			break;

		case VM::ServiceMode:
			std::cout << "Service mode:" << std::endl;
			machine->editCashPool(machine->getCashPool());
			machine->updateCashFile();
			break;

		default:
			break;
		}
	}
}